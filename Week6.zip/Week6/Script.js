// Function to validate form inputs
function validateForm(event) {
    // Prevent the form from submitting
    event.preventDefault();

    // Get form fields
    const username = document.getElementById("username").value.trim();
    const email = document.getElementById("email").value.trim();
    
    // Flag to track form validity
    let isValid = true;

    // Validate username
    if (username === "") {
        document.getElementById("usernameError").style.display = "block";
        isValid = false;
    } else {
        document.getElementById("usernameError").style.display = "none";
    }

    // Validate email
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!emailPattern.test(email)) {
        document.getElementById("emailError").style.display = "block";
        isValid = false;
    } else {
        document.getElementById("emailError").style.display = "none";
    }

    // Show success message if form is valid
    if (isValid) {
        document.getElementById("successMessage").style.display = "block";
    } else {
        document.getElementById("successMessage").style.display = "none";
    }
}

// Event listener for form submission
document.getElementById("myForm").addEventListener("submit", validateForm);

// Function for the interactive button
document.getElementById("interactiveButton").addEventListener("click", function() {
    const dynamicText = document.getElementById("dynamicText");
    dynamicText.textContent = "You clicked the button! The text has changed.";
});
